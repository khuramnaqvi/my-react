function UpdateProduct()
{
    return(
        <div>
            <h1>UpdateProduct</h1>
        </div>
    )
}
export default UpdateProduct