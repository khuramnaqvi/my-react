function AddProduct()
{
    let user= JSON.parse(localStorage.getItem('user-info'));

    return(
        <div>
            <h1>AddProduct {user.f_name} {user.l_name}</h1>
        </div>
    )
}
export default AddProduct