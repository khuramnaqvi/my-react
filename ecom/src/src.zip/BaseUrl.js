function BaseUrl()
{
    let url="http://localhost/react/ecom_laravel/public/api";
    return(
        <div>
           
        </div>
    )
}
export default BaseUrl